#!/bin/bash
chmod +x scrcpy
if [[ -z "$1" ]]; then
  echo "Usage: ./run.sh <device_ip:port>"
  echo "Example: ./run.sh 192.168.1.10:5555"
  exit 1
fi

SCRCPY_SERVER_PATH=scrcpy-server ./scrcpy -s "$1" --no-audio
