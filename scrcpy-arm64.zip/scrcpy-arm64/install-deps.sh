#!/bin/bash
echo "Installing required libraries..."
sudo apt update
sudo apt install -y ffmpeg libsdl2-2.0-0 libusb-1.0-0
echo "Done!"
